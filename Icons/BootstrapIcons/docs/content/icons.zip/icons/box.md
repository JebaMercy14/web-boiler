---
title: Box
layout: icon
categories:
  - Real world
tags:
  - cardboard
  - package
  - cube
---
